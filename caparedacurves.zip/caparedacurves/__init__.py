# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####
# Contributed to by:
# testscreenings, Alejandro Omar Chocano Vasquez, Jimmy Hazevoet, meta-androcto #
# Cmomoney, Jared Forsyth, Adam Newgas, Spivak Vladimir, Jared Forsyth, Atom    #
# Antonio Osprite, Marius Giurgi (DolphinDream)

bl_info = {
    "name": "Capareda Curves",
    "author": "fluiddesigner + testscreenings",
    "version": (0, 1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Add > Curve > caparedacurves",
    "description": "Add extra curve object types",
    "warning": "",
    "wiki_url": "https://www.fluiddesigner.co.uk/",
    "category": "Add Curve"
    }

if "bpy" in locals():
    import importlib
    importlib.reload(add_curve_capareda)

else:
    from . import add_curve_capareda

import bpy
from bpy.props import PointerProperty, CollectionProperty, BoolProperty

def menu(self, context):
    self.layout.operator("curve.capareda", text="Capareda Curve", icon="CURVE_DATA")

# Register
classes = [
    add_curve_capareda.CAPAREDA_OT_capareda,
]

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
		
    bpy.types.VIEW3D_MT_curve_add.append(menu)

def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
		
    bpy.types.VIEW3D_MT_curve_add.remove(menu)

if __name__ == "__main__":
    register()
